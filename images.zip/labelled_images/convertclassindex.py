import glob

txt_files = [file for file in glob.glob('*.txt')]

for file in txt_files:
	with open(file, 'r') as f:
		curr = f.read()
		new = curr.replace('15 ', '1 ')
		with open(file, 'w') as f:
			f.write(new)